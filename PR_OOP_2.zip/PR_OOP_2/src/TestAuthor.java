package authors;
public class TestAuthor {
    public static void main(String[] args) {
        authors.Author a1 = new authors.Author("Mark Twain ", "Marktwain@gmail.com", 'M');
        System.out.println(a1);
    }
}