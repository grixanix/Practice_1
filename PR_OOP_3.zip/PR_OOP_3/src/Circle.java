import java.math .*;
    public class Circle extends Shape {
        protected double radius;

        public Circle() {
            this.filled = false;
            this.color = "Yellow";
            this.radius = 1;
        }

        @Override
        public double getArea() {
            return 0;
        }

        @Override
        public double getPerimeter() {
            return 0;
        }

        @Override
        public String toString() {
            return null;
        }

        public Circle(double radius) {
            this.filled = false;
            this.color = "Blue";
            this.radius = radius;
        }

        public Circle(double radius, String color, boolean filled) {
            this.radius = radius;
            this.color = color;
            this.filled = filled;
        }

        public double getRadius() {
            return radius;
        }

        public void setRadius() {
            this.radius = radius;
        }
    }